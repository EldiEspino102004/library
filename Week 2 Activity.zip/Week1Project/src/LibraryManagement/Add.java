package LibraryManagement;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Add extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField titleField;
    private JTextField authorField;
    private JTextField isbnField;
    private UI uiFrame; // Reference to the UI frame

    public Add(UI uiFrame) {
        this.uiFrame = uiFrame;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 838, 782);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 824, 745);
        contentPane.add(panel);
        panel.setLayout(null);
        
        JLabel lblAddBook = new JLabel("Add New Book");
        lblAddBook.setForeground(new Color(255, 255, 255));
        lblAddBook.setFont(new Font("Sitka Heading", Font.BOLD, 58));
        lblAddBook.setBounds(250, 45, 394, 70);
        panel.add(lblAddBook);
        
        JLabel lblTitle = new JLabel("Title:");
        lblTitle.setForeground(new Color(255, 255, 255));
        lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblTitle.setBounds(76, 215, 80, 30);
        panel.add(lblTitle);
        
        titleField = new JTextField();
        titleField.setBounds(200, 215, 500, 30);
        panel.add(titleField);
        titleField.setColumns(10);
        
        JLabel lblAuthor = new JLabel("Author:");
        lblAuthor.setForeground(new Color(255, 255, 255));
        lblAuthor.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblAuthor.setBounds(76, 306, 80, 30);
        panel.add(lblAuthor);
        
        authorField = new JTextField();
        authorField.setBounds(200, 306, 500, 30);
        panel.add(authorField);
        authorField.setColumns(10);
        
        JLabel lblISBN = new JLabel("ISBN:");
        lblISBN.setForeground(new Color(255, 255, 255));
        lblISBN.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblISBN.setBounds(76, 391, 80, 30);
        panel.add(lblISBN);
        
        isbnField = new JTextField();
        isbnField.setBounds(200, 391, 500, 30);
        panel.add(isbnField);
        isbnField.setColumns(10);
        
        JButton btnAddBook = new JButton("Add Book");
        btnAddBook.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\login1.png"));
        btnAddBook.setBackground(new Color(0, 153, 51));
        btnAddBook.setForeground(new Color(255, 255, 255));
        btnAddBook.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAddBook.setBounds(334, 489, 200, 50);
        panel.add(btnAddBook);
        
        JButton btnClear = new JButton("Clear");
        btnClear.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\back.png"));
        btnClear.setBackground(new Color(255, 0, 0));
        btnClear.setForeground(new Color(255, 255, 255));
        btnClear.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnClear.setBounds(334, 561, 200, 50);
        panel.add(btnClear);
        
        JLabel lblBackground = new JLabel("");
        lblBackground.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\dasdsadsadas.jpg"));
        lblBackground.setBounds(0, 0, 824, 745);
        panel.add(lblBackground);

        btnAddBook.addActionListener(e -> {
            String title = titleField.getText();
            String author = authorField.getText();
            String isbn = isbnField.getText();
            
            // Add book to the system
            uiFrame.addBook(new Book(title, author, isbn));
            dispose(); // Close the Add frame
        });

        btnClear.addActionListener(e -> {
            // Clear all fields
            titleField.setText("");
            authorField.setText("");
            isbnField.setText("");
        });
    }
}
