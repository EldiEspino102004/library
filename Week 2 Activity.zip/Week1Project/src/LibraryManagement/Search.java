package LibraryManagement;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Color;

public class Search extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField searchField;
    private JTextArea resultArea;

    public Search(UI uiFrame) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblSearchBook = new JLabel("Search Books");
        lblSearchBook.setFont(new Font("Sitka Heading", Font.BOLD, 30));
        lblSearchBook.setBounds(200, 20, 200, 40);
        contentPane.add(lblSearchBook);
        
        JLabel lblSearchBy = new JLabel("Search by Title, Author, or ISBN:");
        lblSearchBy.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblSearchBy.setBounds(20, 80, 250, 30);
        contentPane.add(lblSearchBy);
        
        searchField = new JTextField();
        searchField.setBounds(270, 80, 300, 30);
        contentPane.add(searchField);
        searchField.setColumns(10);
        
        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btnSearch.setBounds(270, 120, 100, 30);
        contentPane.add(btnSearch);
        
        resultArea = new JTextArea();
        resultArea.setBounds(20, 170, 550, 150);
        resultArea.setEditable(false);
        contentPane.add(resultArea);
        
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText().toLowerCase();
                ArrayList<Book> books = uiFrame.getBooks();
                StringBuilder results = new StringBuilder();
                
                for (Book book : books) {
                    if (book.getTitle().toLowerCase().contains(query) ||
                        book.getAuthor().toLowerCase().contains(query) ||
                        book.getIsbn().toLowerCase().contains(query)) {
                        results.append(book).append("\n");
                    }
                }
                
                if (results.length() == 0) {
                    resultArea.setText("No books found.");
                } else {
                    resultArea.setText(results.toString());
                }
            }
        });
    }
}
