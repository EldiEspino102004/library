package LibraryManagement;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class TotalBooks extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public TotalBooks(UI uiFrame) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblTotalBooks = new JLabel("Total Number of Books:");
        lblTotalBooks.setForeground(new Color(255, 255, 255));
        lblTotalBooks.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblTotalBooks.setBounds(30, 50, 250, 30);
        contentPane.add(lblTotalBooks);

        JLabel lblCount = new JLabel(String.valueOf(uiFrame.getTotalBooks()));
        lblCount.setForeground(new Color(255, 255, 255));
        lblCount.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblCount.setBounds(30, 100, 150, 50);
        contentPane.add(lblCount);
        
        JLabel lblBackground = new JLabel("");
        lblBackground.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\dasdsadsadas.jpg"));
        lblBackground.setBounds(0, 0, 450, 300);
        contentPane.add(lblBackground);
    }
}
