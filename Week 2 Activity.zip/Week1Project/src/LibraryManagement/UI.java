package LibraryManagement;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;

public class UI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private ArrayList<Book> books = BookDataManager.loadBooks(); // Load books from file

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UI frame = new UI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public UI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 838, 782);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 824, 745);
        contentPane.add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("The Enchanted Exchange");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Sitka Heading", Font.BOLD, 58));
        lblNewLabel.setBounds(120, 37, 657, 116);
        panel.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("A Library Management System");
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setFont(new Font("Sitka Display", Font.PLAIN, 30));
        lblNewLabel_1.setBounds(236, 147, 418, 68);
        panel.add(lblNewLabel_1);
        
        JButton btnAddBook = new JButton("Add Book");
        btnAddBook.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\login1.png"));
        btnAddBook.setBackground(new Color(0, 153, 51));
        btnAddBook.setForeground(new Color(255, 255, 255));
        btnAddBook.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAddBook.setBounds(319, 266, 195, 68);
        panel.add(btnAddBook);
        
        JButton btnRemoveBook = new JButton("Remove Book");
        btnRemoveBook.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\cancel1.png"));
        btnRemoveBook.setBackground(new Color(255, 0, 0));
        btnRemoveBook.setForeground(new Color(255, 255, 255));
        btnRemoveBook.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnRemoveBook.setBounds(319, 363, 195, 68);
        panel.add(btnRemoveBook);
        
        JButton btnSearchBook = new JButton("Search Book");
        btnSearchBook.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\loupe.png"));
        btnSearchBook.setBackground(new Color(0, 51, 204));
        btnSearchBook.setForeground(new Color(255, 255, 255));
        btnSearchBook.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnSearchBook.setBounds(319, 454, 195, 68);
        panel.add(btnSearchBook);
        
        JButton btnNumberOfBooks = new JButton("Total Books");
        btnNumberOfBooks.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\project Image\\account.png"));
        btnNumberOfBooks.setBackground(new Color(255, 255, 0));
        btnNumberOfBooks.setForeground(new Color(0, 0, 0));
        btnNumberOfBooks.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNumberOfBooks.setBounds(319, 558, 195, 68);
        panel.add(btnNumberOfBooks);
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\dasdsadsadas.jpg"));
        lblNewLabel_2.setBounds(10, 11, 814, 734);
        panel.add(lblNewLabel_2);

        btnAddBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Add addFrame = new Add(UI.this); // Pass the current UI frame
                addFrame.setVisible(true);
            }
        });

        btnRemoveBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                remove removeFrame = new remove(books); // Pass the list of books
                removeFrame.setVisible(true);
            }
        });

        btnSearchBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Search searchFrame = new Search(UI.this); // Open search frame
                searchFrame.setVisible(true);
            }
        });

        btnNumberOfBooks.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TotalBooks totalBooksFrame = new TotalBooks(UI.this); // Open total books frame
                totalBooksFrame.setVisible(true);
            }
        });
    }

    public void addBook(Book book) {
        books.add(book); // Add book to the list
        BookDataManager.saveBooks(books); // Save books to file
    }

    public ArrayList<Book> getBooks() {
        return books; // Return the list of books
    }

    public int getTotalBooks() {
        return books.size(); // Return the total number of books
    }
}
