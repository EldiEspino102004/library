package LibraryManagement;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Color;

public class remove extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JList<Book> bookList;
    private DefaultListModel<Book> listModel;
    private ArrayList<Book> books;

    public remove(ArrayList<Book> books) {
        this.books = books;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 838, 782);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 824, 745);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblRemoveBook = new JLabel("Remove Book");
        lblRemoveBook.setForeground(new Color(255, 255, 255));
        lblRemoveBook.setFont(new Font("Sitka Heading", Font.BOLD, 58));
        lblRemoveBook.setBounds(250, 45, 394, 70);
        panel.add(lblRemoveBook);

        listModel = new DefaultListModel<>();
        for (Book book : books) {
            listModel.addElement(book);
        }
        
        bookList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(bookList);
        scrollPane.setBounds(100, 150, 624, 400);
        panel.add(scrollPane);
        
        JButton btnRemoveSelected = new JButton("Remove Selected");
        btnRemoveSelected.setBackground(new Color(255, 0, 0));
        btnRemoveSelected.setForeground(new Color(255, 255, 255));
        btnRemoveSelected.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnRemoveSelected.setBounds(319, 600, 195, 68);
        panel.add(btnRemoveSelected);
        
        JLabel lblBackground = new JLabel("");
        lblBackground.setIcon(new ImageIcon("C:\\Users\\Eldi\\Downloads\\dasdsadsadas.jpg"));
        lblBackground.setBounds(0, 0, 824, 745);
        panel.add(lblBackground);

        btnRemoveSelected.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Book selectedBook = bookList.getSelectedValue();
                if (selectedBook != null) {
                    listModel.removeElement(selectedBook);
                    books.remove(selectedBook); // Remove from the list
                }
            }
        });
    }
}
